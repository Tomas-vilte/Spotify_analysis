def spotify_playlist():
    playlist = {'rap_caviar': 'spotify:playlist:37i9dQZF1DX0XUsuxWHRQd'}
    return playlist

